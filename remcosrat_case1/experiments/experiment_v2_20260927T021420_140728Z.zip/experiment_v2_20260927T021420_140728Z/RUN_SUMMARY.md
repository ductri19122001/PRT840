# Version 2 run summary

Status: generated_with_check_failures

Development check on Case Study 1. Independent human review is pending.

Passing automated checks does not establish mapping accuracy.

| Condition | Seed | Automated checks | Issues |
|---|---:|---|---|
| fixed_reference | 42 | False | mapping[0]: positive mapping requires observed support; no-behaviour/CTI-only support is insufficient; mapping[1]: positive mapping requires observed support; no-behaviour/CTI-only support is insufficient; Every supplied technique must be assessed once, including justified rejections; evidence_assessment.connection_states: exact supplied values omitted: 1, 106, 33747; evidence_assessment.byte_direction: exact supplied values omitted: 71, 1213, 435984, 190672103 |
| retrieved_reference | 42 | False | Every supplied technique must be assessed once, including justified rejections; evidence_assessment.connection_states: exact supplied values omitted: 1, 8, 106, 33630, 33747; evidence_assessment.byte_direction: exact supplied values omitted: 71, 1213, 435984, 190672103 |

Read each response_readable.md alongside the input and validation.json.
Fill in retrieval_review.csv and human_review.csv before reporting substantive results.
The adjacent ZIP is a snapshot made immediately after generation; it does not contain later reviewer edits.
